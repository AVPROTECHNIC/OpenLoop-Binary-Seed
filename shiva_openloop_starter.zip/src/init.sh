#!/bin/bash
# This script starts the OpenLoop

echo 'OpenLoop initialized. Frequency stable.'